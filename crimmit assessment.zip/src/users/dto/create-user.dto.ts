export class CreateUsersDto{
    readonly userID: string;
    readonly name: string;
    readonly email: string;
    readonly password: string;
    readonly documentID: string;
}