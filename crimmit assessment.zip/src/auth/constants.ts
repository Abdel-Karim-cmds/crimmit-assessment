export const jwtConstants = {
    secret: 'f4897ds93DsXX@SFJ1XX48789hjKJDdfhjk4979',
  };